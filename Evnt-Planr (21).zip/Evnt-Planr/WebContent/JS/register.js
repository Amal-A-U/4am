
function validate(){
	if(document.register.firstName.value === ""){
		alert("Please Enter your First Name");
		document.register.firstName.focus();
		return false;
	}
	if(document.register.lastName.value === ""){
		alert("Please Enter your Last Name");
		document.register.lastNameame.focus();
		return false;
	}
	if(document.register.eid.value === ""){
		alert("Please Enter your Employee id ");
		document.register.eid.focus();
		return false;
	}
	if(document.register.gender.value === ""){
		alert("Please Select your Gender");
		document.register.gender.focus();
		return false;
	}
	if(document.register.age.value === ""){
		alert("Please enter your age");
		document.register.age.focus();
		return false;
		
	}
/*	if(isNaN(document.register.age.value)){
		alert("Please Enter a valid age");
		document.register.age.focus();
		return false;
	}*/
	var age=document.getElementById('age').value;
	// Convert user entered age to a number
	age = parseInt(age, 10);
	//check if age is a number or less than or greater than 100
	if (isNaN(age) || age < 18 || age > 75)
	{ 
	  alert("The age must be a number between 18 and 75");
	  return false;
	}
	if (document.register.email.value === "") {
		alert("Please enter your email id");
		document.register.email.focus();
		return false;
	}
	var reg = /^([A-Za-z0-9_])+([A-Za-z0-9_\-\.])*\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	if (reg.test(document.register.email.value) === false) {
		alert("Please enter your valid email id");
		document.register.email.focus();
		return false;
	}
	if(document.register.phone.value === ""){
		alert("Please Enter your Mobile Number");
			document.register.phone.focus();
		return false;
		}
    var r=/^[789]/;
	if (r.test(document.register.phone.value) === false) {
		alert("Please check starting digit, enter your valid phone number");
		document.register.phone.focus();
		return false;
	}
	if(isNaN(document.register.phone.value)){
		alert("Please Enter a valid Phone Number");
		document.register.phone.focus();
		return false;
	}
	if(!(document.register.phone.value.length ===10)){
		alert("Please Enter a 10 digit Number");
		document.register.phone.focus();
		return false;
	}
	if (document.register.dept.value === "") {
		alert("Please enter your department");
		document.register.dept.focus();
		return false;
	}
	if(document.register.password.value === ""){
		alert("Please Enter the password");
		document.register.password.focus();
		return false;
	}
	
	var reg = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
	if (reg.test(document.register.password.value) === false) {
		alert("Please enter a valid password  Must contain at least one number and  one uppercase and lowercase letterand at least 8 or more characters");
		document.register.email.focus();
		return false;
	}
	
	
	
	if(document.register.password1.value === ""){
		alert("Please Enter the password");
		document.register.password1.focus();
		return false;
	}
 	
 	if (document.register.password.value !== document.register.password1.value) {
		alert("Password doesnot match");
		document.register.password.focus();
		return false;
	} 
 
	return true;
}