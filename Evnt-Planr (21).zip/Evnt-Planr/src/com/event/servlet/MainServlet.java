package com.event.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.bean.Department;
import com.event.bean.Employee;
import com.event.dao.DropDownDeptDao;
import com.event.dao.MainDao;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		
	
	try{
		MainDao objMainDao=new MainDao();

Employee objEmpBean=new Employee();
objEmpBean.setFirstName(request.getParameter("firstName"));
objEmpBean.setLastName(request.getParameter("lastName"));
objEmpBean.setEid(request.getParameter("eid"));
objEmpBean.setGender(request.getParameter("gender"));
objEmpBean.setAge(request.getParameter("age"));
objEmpBean.setEmail(request.getParameter("email"));
objEmpBean.setPhone(request.getParameter("phone"));
objEmpBean.setDept(request.getParameter("dept"));
objEmpBean.setPassword(request.getParameter("password"));


int r=objMainDao.InsertAdmin(objEmpBean);
if(r==0)
		request.setAttribute("AdminReg", "Registration failed  !");
else
		request.setAttribute("AdminReg", "Registration successful");

DropDownDeptDao objDropDownDeptDao=new DropDownDeptDao();
List<Department> dlist = objDropDownDeptDao.Deptlist();
request.setAttribute("department", dlist);

RequestDispatcher dispatcher = request.getRequestDispatcher("/Main.jsp");
dispatcher.forward(request, response);



	}catch(Exception e){
		e.printStackTrace();
	}
	}

	}

