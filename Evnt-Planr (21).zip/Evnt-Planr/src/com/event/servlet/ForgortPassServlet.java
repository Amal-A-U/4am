package com.event.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.event.bean.Employee;
import com.event.bean.Login_FormBean;
import com.event.dao.Login;

@WebServlet("/ForgortPassServlet")
public class ForgortPassServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   int s=0;
    public ForgortPassServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Employee objEmployee= new Employee();
		objEmployee.setEmail(request.getParameter("email"));
		Login objLoginDao= new Login();
	 try {
		s = objLoginDao.forgotPass(objEmployee);
	} catch (SQLException e) {
	
		e.printStackTrace();
	} catch (AddressException e) {
	
		e.printStackTrace();
	} catch (MessagingException e) {
		
		e.printStackTrace();
	}
	
	 if(s==1){
			String fp = "Check your Mail for UserName and Password !";
			request.setAttribute("fp", fp);
			RequestDispatcher dispatcher =request.getRequestDispatcher("/login.jsp");
			dispatcher.forward(request, response);
	 }
	 else{
		 String fp = "The Email is not a registered Email !";
			request.setAttribute("fp", fp);
			RequestDispatcher dispatcher =request.getRequestDispatcher("/login.jsp");
			dispatcher.forward(request, response);
	 }
	}

}
