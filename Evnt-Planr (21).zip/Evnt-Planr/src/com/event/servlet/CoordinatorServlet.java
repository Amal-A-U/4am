package com.event.servlet;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.event.bean.Employee;
import com.event.dao.DropDownEmpDao;
@WebServlet("/CoordinatorServlet")
public class CoordinatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		String id=(String)session.getAttribute("uid");
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		if (null == id) {
		          request.setAttribute("Error", "Session Expired....  Please login again to continue.");
		           request.getRequestDispatcher("/home.jsp").forward(request, response);
		}
		try
		{   DropDownEmpDao objDropDownEmpDao=new DropDownEmpDao();
			List<Employee> emplist = objDropDownEmpDao.list(id);
			request.setAttribute("employList", emplist);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/add-event-inner.jsp");
			dispatcher.forward(request, response);
	}
		catch(Exception e){
			e.printStackTrace();
		}

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
