package com.event.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.event.bean.Department;
import com.event.bean.Login_FormBean;
import com.event.dao.DropDownDeptDao;
import com.event.dao.Login;

/**
 * Servlet implementation class Login_Form
 */
@WebServlet("/Login_Form")
public class Login_Form extends HttpServlet {
	EmpHomeServlet objEmpHomeServlet=new EmpHomeServlet();
	EventList objEventList = new EventList();
	public String s=null;
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		Login_FormBean objLogin_FormBean= new Login_FormBean();
		objLogin_FormBean.setUsername(request.getParameter("employee-id"));
		objLogin_FormBean.setPassword(request.getParameter("password"));
		Login objLoginFormDao= new Login();
		
			HttpSession session=request.getSession(true);
			 s = objLoginFormDao.CheckCredentials(objLogin_FormBean);
			 objLoginFormDao.CheckDate();
		
		if(s.equals("admin")){
			session.setAttribute("uid",request.getParameter("employee-id"));
		
			response.setHeader("Cache-Control","no-cache"); 
			response.setHeader("Cache-Control","no-store"); 
			response.setDateHeader("Expires", 0); 
			response.setHeader("Pragma","no-cache");
		
			objEventList.listEvents(request,response);
		
		}
		else if(s.equals("employee")){
			session.setAttribute("uid",request.getParameter("employee-id"));
			
			response.setHeader("Cache-Control","no-cache"); 
			response.setHeader("Cache-Control","no-store"); 
			response.setDateHeader("Expires", 0); 
			response.setHeader("Pragma","no-cache");
			
			objEmpHomeServlet.emphome(request,response);
	
		}
		else if(s.equals("Main")){
			session.setAttribute("uid",request.getParameter("employee-id"));
			
			response.setHeader("Cache-Control","no-cache"); 
			response.setHeader("Cache-Control","no-store"); 
			response.setDateHeader("Expires", 0); 
			response.setHeader("Pragma","no-cache");
			DropDownDeptDao objDropDownDeptDao=new DropDownDeptDao();
			List<Department> dlist = objDropDownDeptDao.Deptlist();
			request.setAttribute("department", dlist);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/Main.jsp");
			dispatcher.forward(request, response);
			
	
		}
		else{
			String[] msg = {"Invalid User Name or Password  please try again !"};
			request.setAttribute("msg", msg);
			RequestDispatcher dispatcher =request.getRequestDispatcher("/login.jsp");
			dispatcher.forward(request, response);
		}
	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
