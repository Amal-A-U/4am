package com.event.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.event.bean.Department;
import com.event.dao.DropDownDeptDao;
import com.event.dao.MainDao;

/**
 * Servlet implementation class AddDepartmentServlet
 */
@WebServlet("/AddDepartmentServlet")
public class AddDepartmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control","no-cache"); 
		response.setHeader("Cache-Control","no-store"); 
		response.setDateHeader("Expires", 0); 
		response.setHeader("Pragma","no-cache");
		
	
		try
		{
			Department objDept = new Department();
			objDept.setDept_id(request.getParameter("deptId"));
			objDept.setDept_name(request.getParameter("deptName"));
			MainDao objMainDao=new MainDao();
			int s= objMainDao.AddDept(objDept);
			if(s==1)
			request.setAttribute("AddDept", "Department added Successfully");
			else
			request.setAttribute("AddDept", "Department addition Failed");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/addDepartment.jsp");
			dispatcher.forward(request, response);
	}
		catch(Exception e){
			e.printStackTrace();
		}

	}

}
