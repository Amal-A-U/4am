package com.event.bean;

public class Event {
	private  String event_id;
	private  String event_name;
	private  String start_date;
	private  String end_date;
	private  String venue;
	private  String event_time;
	private  Float expected_amount;
	private  Float total_amount;
	private  String event_status;
	private String admin_id;
	private String coordinator_id;
	private Float emp_expect_amt;
	private String emp_contribute_amt;





	public Event(String event_id, String event_name, String start_date, String end_date, String venue,
			String event_time, Float expected_amount, Float total_amount, String event_status, String admin_id,
			String coordinator_id, Float emp_expect_amt, String emp_contribute_amt) {
		super();
		this.event_id = event_id;
		this.event_name = event_name;
		this.start_date = start_date;
		this.end_date = end_date;
		this.venue = venue;
		this.event_time = event_time;
		this.expected_amount = expected_amount;
		this.total_amount = total_amount;
		this.event_status = event_status;
		this.admin_id = admin_id;
		this.coordinator_id = coordinator_id;
		this.emp_expect_amt = emp_expect_amt;
		this.setEmp_contribute_amt(emp_contribute_amt);
	}

	public Event(String event_id, String event_name, String start_date, String end_date, String venue,
			String event_time, Float expected_amount, Float total_amount, String event_status, String admin_id,
			String coordinator_id, Float emp_expect_amt) {
		super();
		this.event_id = event_id;
		this.event_name = event_name;
		this.start_date = start_date;
		this.end_date = end_date;
		this.venue = venue;
		this.event_time = event_time;
		this.expected_amount = expected_amount;
		this.total_amount = total_amount;
		this.event_status = event_status;
		this.admin_id = admin_id;
		this.coordinator_id = coordinator_id;
		this.emp_expect_amt = emp_expect_amt;
	}

	public Event(String event_name, String start_date, String end_date, String venue, String event_time,
			Float expected_amount, Float total_amount, String event_status, String admin_id, String coordinator_id,
			Float emp_expect_amt) {
		super();
		this.event_name = event_name;
		this.start_date = start_date;
		this.end_date = end_date;
		this.venue = venue;
		this.event_time = event_time;
		this.expected_amount = expected_amount;
		this.total_amount = total_amount;
		this.event_status = event_status;
		this.admin_id = admin_id;
		this.coordinator_id = coordinator_id;
		this.emp_expect_amt = emp_expect_amt;
	}

	public Event() {
	
	}

	public Event(String event_id, String eventname, String startdate, String enddate, String venue, String time,
			Float expect_amount, String coordinator_id, Float emp_expect_amount) {
		this.event_id = event_id;
		this.event_name = eventname;
		this.start_date = startdate;
		this.end_date = enddate;
		this.venue = venue;
		this.event_time = time;
		this.expected_amount = expect_amount;
		this.coordinator_id = coordinator_id;
		this.emp_expect_amt = emp_expect_amount;
	}



	/**
	 * @return the event_id
	 */
	public String getEvent_id() {
		return event_id;
	}
	/**
	 * @param event_id the event_id to set
	 */
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	/**
	 * @return the event_name
	 */
	public String getEvent_name() {
		return event_name;
	}
	/**
	 * @param event_name the event_name to set
	 */
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}
	/**
	 * @return the start_date
	 */
	public String getStart_date() {
		return start_date;
	}
	/**
	 * @param start_date the start_date to set
	 */
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	/**
	 * @return the end_date
	 */
	public String getEnd_date() {
		return end_date;
	}
	/**
	 * @param end_date the end_date to set
	 */
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	/**
	 * @return the venue
	 */
	public String getVenue() {
		return venue;
	}
	/**
	 * @param venue the venue to set
	 */
	public void setVenue(String venue) {
		this.venue = venue;
	}

	/**
	 * @return the event_time
	 */
	public String getEvent_time() {
		return event_time;
	}
	/**
	 * @param event_time the event_time to set
	 */
	public void setEvent_time(String event_time) {
		this.event_time = event_time;
	}
	/**
	 * @return the expected_amount
	 */
	public Float getExpected_amount() {
		return expected_amount;
	}
	/**
	 * @param expected_amount the expected_amount to set
	 */
	public void setExpected_amount(Float expected_amount) {
		this.expected_amount = expected_amount;
	}
	/**
	 * @return the total_amount
	 */
	public Float getTotal_amount() {
		return total_amount;
	}
	/**
	 * @param total_amount the total_amount to set
	 */
	public void setTotal_amount(Float total_amount) {
		this.total_amount = total_amount;
	}
	/**
	 * @return the event_status
	 */
	public String getEvent_status() {
		return event_status;
	}
	/**
	 * @param event_status the event_status to set
	 */
	public void setEvent_status(String event_status) {
		this.event_status = event_status;
	}

	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	public String getCoordinator_id() {
		return coordinator_id;
	}

	public void setCoordinator_id(String coordinator_id) {
		this.coordinator_id = coordinator_id;
	}

	/**
	 * @return the emp_expect_amt
	 */
	public Float getEmp_expect_amt() {
		return emp_expect_amt;
	}

	/**
	 * @param emp_expect_amt the emp_expect_amt to set
	 */
	public void setEmp_expect_amt(Float emp_expect_amt) {
		this.emp_expect_amt = emp_expect_amt;
	}

	@Override
	public String toString() {
		return "AddEventBean [event_id=" + event_id + ", event_name=" + event_name + ", start_date=" + start_date
				+ ", end_date=" + end_date + ", venue=" + venue + ", event_time=" + event_time + ", expected_amount="
				+ expected_amount + ", total_amount=" + total_amount + ", event_status=" + event_status + ", admin_id="
				+ admin_id + ", coordinator_id=" + coordinator_id + "]";
	}

	/**
	 * @return the emp_contribute_amt
	 */
	public String getEmp_contribute_amt() {
		return emp_contribute_amt;
	}

	/**
	 * @param emp_contribute_amt the emp_contribute_amt to set
	 */
	public void setEmp_contribute_amt(String emp_contribute_amt) {
		this.emp_contribute_amt = emp_contribute_amt;
	}






	
	
	
}
