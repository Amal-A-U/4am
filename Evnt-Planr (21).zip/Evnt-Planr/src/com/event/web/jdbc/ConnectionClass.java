package com.event.web.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import java.util.Properties;

public class ConnectionClass  {
	private static Connection conn;
	
	
	 public static Connection getConnection() throws FileNotFoundException {
		 
		 Properties property = new Properties();
		 InputStream input = null;
		 input = new FileInputStream("/workspace1/Evnt-Planr/config.properties");
		 // load a properties file
		 try {
		                 property.load(input);
		                 input.close();
		 } catch (IOException e1) {
		                 // TODO Auto-generated catch block
		                 e1.printStackTrace();
		 }

	        try {
	          
	            Class.forName(property.getProperty("ojdbc.driver"));
	           
	            try {
	            	 conn = DriverManager.getConnection(property.getProperty("ojdbc.url"), property.getProperty("ojdbc.username"),property.getProperty("ojdbc.password")); 
	            	// System.out.println("driver manager."); 
	            }
	            catch (SQLException ex) {
	          
	                System.out.println("Failed to create the database connection."); 
	            }
	        } 
	        catch (ClassNotFoundException ex) {
	        
	            System.out.println("Driver not found."); 
	        }
	        return conn;
	    }
}



   


