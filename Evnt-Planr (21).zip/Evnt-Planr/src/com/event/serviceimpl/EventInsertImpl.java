package com.event.serviceimpl;

public class EventInsertImpl {

}
