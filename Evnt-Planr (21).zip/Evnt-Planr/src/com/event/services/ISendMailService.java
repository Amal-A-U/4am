/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.event.services;

import java.util.List;

/**
 *
 * @author admin
 */
public interface ISendMailService {

    public Boolean sendMail(List email,String subject ,String message);

}
