package com.event.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.event.bean.Department;
import com.event.bean.Employee;
import com.event.web.jdbc.ConnectionClass;

public class MainDao {
	Connection con=null;
	Statement stmt= null;
	PreparedStatement ps=null;
	
	public int AddDept(Department objDept) throws FileNotFoundException, SQLException {
		int r=0;
		
		String dept_id=objDept.getDept_id();
		String dept_name=objDept.getDept_name();
		con=ConnectionClass.getConnection();
		stmt=con.createStatement();
		String sql="insert into amal_department(dept_id,dept_name) values(?,?)";
		ps=con.prepareStatement(sql);
		ps.setString(1,dept_id);
		ps.setString(2,dept_name);
		r=ps.executeUpdate();
		return r;
	}


	
	public int InsertAdmin(Employee objEmpBean) throws FileNotFoundException, SQLException {
		int r=0;
		con=ConnectionClass.getConnection();
		
			PreparedStatement ps =null;
			String status="admin";
			String eid=objEmpBean.getEid();
			String fn=objEmpBean.getFirstName();
			String ln=objEmpBean.getLastName();
			String age=objEmpBean.getAge();
			String gender=objEmpBean.getGender();
			String did=objEmpBean.getDept();
			String email=objEmpBean.getEmail();
			String ph=objEmpBean.getPhone();
			String pass=objEmpBean.getPassword();
	
		String sql="insert into AMAL_EMPLOYEE (EMPLOYEE_ID,FNAME,LNAME,AGE,GENDER,DEPT_ID,EMAIL,PHONE,PASSWORD,STATUS) values(?,?,?,?,?,?,?,?,?,?)";
		 ps=con.prepareStatement(sql);
		  ps.setString(1,eid);
		  ps.setString(2,fn);
		  ps.setString(3,ln);
		  ps.setString(4,age);
		  ps.setString(5,gender);
		  ps.setString(6,did);
		  ps.setString(7,email);
		  ps.setString(8,ph);
		  ps.setString(9,pass);
		  ps.setString(10,status);
		  r=ps.executeUpdate();

		return r;


}


}
