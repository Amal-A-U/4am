package com.event.dao;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

import com.event.serviceimpl.SendMail;
import com.event.web.jdbc.ConnectionClass;


public class AdminHomeDao {
	
	public String AcceptEvent(String event_id) throws Exception{
		Connection con=null;
		Statement stmt= null;
		int rs = 0;
		PreparedStatement ps=null;
		String status="approved";
		String s=null;
		try{
			con=ConnectionClass.getConnection();
			String sql="update amal_event set event_status=? where event_id=?";
			stmt= con.createStatement();
		
			ps=con.prepareStatement(sql);
			 ps.setString(1,status);
			 ps.setString(2,event_id);
	    	rs=ps.executeUpdate();
		
			//process result set
			if(rs==1)
				s="success";
				else
					s="fail";
	
			
			
			Statement stmt4= null;
			ResultSet rs4 = null;
			PreparedStatement ps4=null;
			String admin_id=null;
			String eventname=null;
			String startdate=null;
			String venue=null;
			String coordinator_id=null;
				//create sql statement
				String sql4="select * from AMAL_EVENT where event_id=?";
				stmt4= con.createStatement();
				ps4=con.prepareStatement(sql4);
		
				ps4.setString(1,event_id);
		
		    	rs4=ps4.executeQuery();
				while(rs4.next()){
					// retrieve data from result set row
					 eventname=rs4.getString("EVENT_NAME");
					 startdate=rs4.getString("START_DATE");
					venue=rs4.getString("VENUE");
					 admin_id=rs4.getString("ADMIN_ID");
					 coordinator_id=rs4.getString("COORDINATOR_ID");
					
				}
			
		
			
		    ResultSet rs0=null;
		     PreparedStatement ps0=null;
		     String status0="employee";
		
		     System.out.println("b");
		 	  String sql2="select email from amal_employee where dept_id in (select dept_id from amal_employee where employee_id=?) and status=? ";
		 	 List<String> list=new ArrayList<String>();
		 		ps0=con.prepareStatement(sql2);
		 		 ps0.setString(1,admin_id);
		 		 ps0.setString(2,status0);
		 	    rs0 = ps0.executeQuery();
		 	System.out.println("c");
		 	while(rs0.next()){
		 		System.out.println("d");
		 		list.add(rs0.getString("EMAIL"));
		 	}
		 	System.out.println("e");
		     String body="Hi\n \tEVENT NAME :"+eventname.toUpperCase()+"\n \tDATE:"+startdate+"\n\tVENUE:"+venue.toUpperCase()+"\n\tCO-ORDINATOR:"+coordinator_id+"\n\n\nALL ARE WELCOME!!\n\nThanks and regards\nAmal AU ";
		  
		
		 
		     SendMail objMail= new SendMail();
		     objMail.sendEmail(eventname,list,"extern_au.amal@allianz.com",body);
			
			
			
			
			
			
			return s;
		}
		finally{
			//close jdbc objects
			stmt.close();
			con.close();
		}
		
	}
	
	public String RejectEvent(String event_id) throws Exception{
		Connection con=null;
		Statement stmt= null;
		int rs = 0;
		PreparedStatement ps=null;
		String status="rejected";
		String s=null;
		try{
			con=ConnectionClass.getConnection();
			String sql="update amal_event set event_status=? where event_id=?";
			stmt= con.createStatement();
		
			ps=con.prepareStatement(sql);
			 ps.setString(1,status);
			 ps.setString(2,event_id);
	    	rs=ps.executeUpdate();
		
			//process result set
			if(rs==1)
				s="success";
				else
					s="fail";
	
			return s;
		}
		finally{
			//close jdbc objects
			stmt.close();
			con.close();
		}
		
	}


	

	

}
