package com.event.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.event.bean.Employee;
import com.event.bean.Event;
import com.event.web.jdbc.ConnectionClass;

public class EmpHomeDao {
	
	
	public List<Event> GetEvents(Employee objEmp) throws Exception{
		List<Event> list_AddEventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		PreparedStatement ps1=null;
		PreparedStatement ps=null;
		try{
			con=ConnectionClass.getConnection();
			stmt= con.createStatement();
			
			String sql1="select employee_id from amal_employee where dept_id in (select dept_id from amal_employee where employee_id=?) and status='admin'";
			String employee_id=objEmp.getEid();
			
			String adminId = null;
			ps1=con.prepareStatement(sql1);
			ps1.setString(1,employee_id);
	    	rs1=ps1.executeQuery();
		
	    	System.out.println("EmpHomeDao");
			while(rs1.next()){
				 adminId=rs1.getString("employee_id");
			}
			
			

			String event_status="approved";
					
					//create sql statement
					String sql="select * from AMAL_EVENT e  where e.admin_id=? and e.event_status=? and e.event_id not in (select d.event_id from  AMAL_EVENT_DETAILS d where d.employee_id=?)";
					ps=con.prepareStatement(sql);
					 ps.setString(1,adminId);
					 ps.setString(2,event_status);
				
					 ps.setString(3,employee_id);
			    	rs=ps.executeQuery();
			    	
	    	
			//process result set
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id,coordinator_id,emp_expect_amt);
				list_AddEventBean.add(tempEvent);
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_AddEventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}
	
	
	private void close(Connection con, Statement stmt, ResultSet rs) {
		try{
			if(rs!=null){
				rs.close();
			}
			if(stmt!=null){
				stmt.close();
			}
			if(con!=null){
				con.close();
			}
			
		}
		catch(Exception exc){
			exc.printStackTrace();
		}
	}


	public String accept(Float contribute, String event_id,String employee_id,float total_amount) {
		Connection con=null;
		Statement stmt= null;
		int rs = 0;
		int rs1=0;
		PreparedStatement ps=null;
		System.out.println("action3");
		PreparedStatement ps1=null;
		System.out.println(contribute);
		System.out.println(total_amount);
		String emp_status="accept";
	/*	float cont= Float.parseFloat(contribute);
		System.out.println(cont);*/
		
		System.out.println(total_amount);
	
		
		Float total=total_amount+contribute;
		System.out.println("total "+total);
		String s=null;
		try{
			con=ConnectionClass.getConnection();
			stmt= con.createStatement();
			/*String sql="insert into amal_event_details(event_id,employee_id,emp_contribute_amt,employee_status)values(?,?,?,?)";*/
			String sql="insert into amal_event_details(event_id,employee_id,emp_contribute_amt,employee_status) values (?,?,?,?)";
			ps=con.prepareStatement(sql);
			 ps.setString(1,event_id);
			 ps.setString(2,employee_id);
			 ps.setFloat(3,contribute);
			 ps.setString(4,emp_status);
	    	rs=ps.executeUpdate();
	    	if(rs==1)
	    	{
	    		System.out.println("s1");
				s="success";
	    	}
			else
				s="fail";
	    	
	    	String sql1="update amal_event set total_amount=? where event_id=?";
	    			ps1=con.prepareStatement(sql1);
			 ps1.setFloat(1,total);
			 ps1.setString(2,event_id);
			 rs1=ps1.executeUpdate();
			 if(s.equals("fail"))
		    	if(rs1==1)
		    	{
		    		System.out.println("s2");
		    		s="success";
		    		
		    	}
				else
					s="fail";		
		}
		catch(Exception exc){
			exc.printStackTrace();
		}
		return s;
	}
	public String reject(String event_id, String employee_id) {
		Connection con=null;
		Statement stmt= null;
		int rs = 0;
		System.out.println("daoreject");
		PreparedStatement ps=null;
		String emp_status="reject";
	
		String s=null;
		try{
			float contribute=0;
			con=ConnectionClass.getConnection();
			stmt= con.createStatement();
			/*String sql="insert into amal_event_details(event_id,employee_id,employee_status)values(?,?,?)";*/
			String sql="insert into amal_event_details(event_id,employee_id,emp_contribute_amt,employee_status) values (?,?,?,?)";
			ps=con.prepareStatement(sql);
			 ps.setString(1,event_id);
			 ps.setString(2,employee_id);
			 ps.setFloat(3,contribute);
			 ps.setString(4,emp_status);
	    	rs=ps.executeUpdate();
	    	if(rs==1)
	    	{
	    		System.out.println("sucess");
				s="success";
	    	}
			else
			{
				s="fail";
	    	System.out.println("fail");
			}
			
		}
		catch(Exception exc){
			exc.printStackTrace();
		}
		return s;
	}
	public List<Event> EventAccepted(String emp_id) throws SQLException, FileNotFoundException {
		List<Event> list_EventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		PreparedStatement ps1=null;
		PreparedStatement ps=null;
		try{
			con=ConnectionClass.getConnection();
			stmt= con.createStatement();
			
			String sql1="select employee_id from amal_employee where dept_id in (select dept_id from amal_employee where employee_id=?) and status='admin'";

			
			String adminId = null;
			ps1=con.prepareStatement(sql1);
			ps1.setString(1,emp_id);
	    	rs1=ps1.executeQuery();
		
	    	System.out.println("EmpHomeDao");
			while(rs1.next()){
				 adminId=rs1.getString("employee_id");
			}
			
			
			
			String employee_status="accept";
			//create sql statement
			String sql="select * from AMAL_EVENT e, AMAL_EVENT_DETAILS d where e.admin_id=?  and e.event_id=d.event_id and d.employee_status=? and employee_id=?";
			ps=con.prepareStatement(sql);
			 ps.setString(1,adminId);
			 ps.setString(2,employee_status);
			 ps.setString(3,emp_id);
	    	rs=ps.executeQuery();
	    	
			//process result set
			while(rs.next()){
				
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				String emp_contribute_amt=rs.getString("EMP_CONTRIBUTE_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id,coordinator_id,emp_expect_amt,emp_contribute_amt);
				list_EventBean.add(tempEvent);
				
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_EventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
	}
	public List<Event> EventRejected(String emp_id) throws SQLException, FileNotFoundException {
		List<Event> list_EventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		PreparedStatement ps1=null;
		PreparedStatement ps=null;
		try{
			con=ConnectionClass.getConnection();
			stmt= con.createStatement();
			
			String sql1="select employee_id from amal_employee where dept_id in (select dept_id from amal_employee where employee_id=?) and status='admin'";
		
			
			String adminId = null;
			ps1=con.prepareStatement(sql1);
			ps1.setString(1,emp_id);
	    	rs1=ps1.executeQuery();
		
	    	System.out.println("EmpHomeDao");
			while(rs1.next()){
				 adminId=rs1.getString("employee_id");
			}
			
			
			
			String employee_status="reject";
			//create sql statement
			String sql="select * from AMAL_EVENT e, AMAL_EVENT_DETAILS d where e.admin_id=? and  e.event_id=d.event_id and d.employee_status=? and employee_id=?";
			ps=con.prepareStatement(sql);
			 ps.setString(1,adminId);
			 ps.setString(2,employee_status);
			 ps.setString(3,emp_id);
	    	rs=ps.executeQuery();
	    	
			//process result set
			while(rs.next()){
				
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
			
				
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id,coordinator_id,emp_expect_amt);
				list_EventBean.add(tempEvent);
				
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_EventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
		
		
		
	
	}


	public String getName(String employee_id) throws SQLException, FileNotFoundException {
		Connection con=null;
		Statement stmt9= null;
		ResultSet rs9 = null;
		PreparedStatement ps9=null;
		con=ConnectionClass.getConnection();
		stmt9= con.createStatement();
		
		
		String fname=null;
		//create sql statement
		System.out.println("q");
		String sql9="select FNAME from AMAL_employee where employee_id=?";
		System.out.println("w");
		ps9=con.prepareStatement(sql9);
		System.out.println("e");
		 ps9.setString(1,employee_id);
		 System.out.println("r");
    	rs9=ps9.executeQuery();
    	
		//process result set
		while(rs9.next()){
			
			fname=rs9.getString("fname");
			System.out.println("fname");
		}
		
		return fname;
	}


	

}
