package com.event.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import com.event.bean.Employee;
import com.event.bean.Event;
import com.event.bean.Event_Details;
import com.event.web.jdbc.ConnectionClass;

public class ViewEventDao {

	public List<Event> GetEvents(String admin_id) throws Exception{
		System.out.println("get event");
		List<Event> list_AddEventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try{
			String status="approved";
			System.out.println("sql");
			//get a connection
			con=ConnectionClass.getConnection();
			//create sql statement
			String sql="select * from AMAL_EVENT where event_status=? and admin_id =? ";
			/*where EVENT_STATUS='approved'*/
			stmt= con.createStatement();
			//execute query
			ps=con.prepareStatement(sql);
			 ps.setString(1,status);
			 ps.setString(2,admin_id);
	    	rs=ps.executeQuery();
	    	System.out.println("sql");
			//process result set
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String event_status=rs.getString("EVENT_STATUS");
				String admin_id1=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,event_status,admin_id1,coordinator_id,emp_expect_amt);
				list_AddEventBean.add(tempEvent);
				System.out.println("get event");
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_AddEventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}

	public List<Event> AllEvents(String admin_id, String content1) throws SQLException, FileNotFoundException {
		List<Event> listEvents = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try{
		
			String status="approved";
			String status1="closed";
			System.out.println("sql");
		
			con=ConnectionClass.getConnection();
			String sql="select distinct * from AMAL_EVENT where( (UPPER(event_name) like ? or  UPPER(venue) like ? or  UPPER(event_time) like ? or  UPPER(event_status) like ? )and (event_status=? or event_status=?))";
			stmt= con.createStatement();
			String content=content1.toUpperCase();
			ps=con.prepareStatement(sql);
			 ps.setString(1,"%"+content+"%");
			 ps.setString(2,"%"+content+"%");
			 ps.setString(3,"%"+content+"%");
			 ps.setString(4,"%"+content+"%");
			 ps.setString(5,status);
			 ps.setString(6,status1);
		
		
	    	rs=ps.executeQuery();
	    	System.out.println("sql");
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id1=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id1,coordinator_id,emp_expect_amt);
				listEvents.add(tempEvent);
				System.out.println("get event");
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return listEvents;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
	}


	public List<Event_Details> EventInner(String admin_id) throws SQLException, FileNotFoundException {
		List<Event_Details> listEventDetails = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try{
			String status="approved";
		
			//get a connection
			con=ConnectionClass.getConnection();
			//create sql statement
			String sql="select d.event_id,d.employee_id,d.employee_status,d.emp_contribute_amt,e.emp_expect_amt FROM AMAL_EVENT e join AMAL_EVENT_DETAILS d on e.event_id=d.event_id and e.event_status=? and e.admin_id =?";
			/*where EVENT_STATUS='approved'*/
			stmt= con.createStatement();
			//execute query
			ps=con.prepareStatement(sql);
			 ps.setString(1,status);
			 ps.setString(2,admin_id);
	    	rs=ps.executeQuery();
	    	System.out.println("sql");
			//process result set
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String employee_id=rs.getString("employee_id");
				String employee_status=rs.getString("employee_status");
				String emp_contribute_amt=rs.getString("emp_contribute_amt");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event_Details tempEvent_Details = new Event_Details(eventId,employee_id,employee_status,emp_expect_amt,emp_contribute_amt);
				listEventDetails.add(tempEvent_Details);
				System.out.println("get event");
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return listEventDetails;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}

	public List<Event_Details> EventInner(String admin_id,String event_id) throws SQLException, FileNotFoundException {
		List<Event_Details> listEventDetails = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try{
		
		
			//get a connection
			con=ConnectionClass.getConnection();
			//create sql statement
			String sql="select * from amal_event_details where event_id=?";
			/*where EVENT_STATUS='approved'*/
			stmt= con.createStatement();
			//execute query
			ps=con.prepareStatement(sql);
			 ps.setString(1,event_id);
	    	rs=ps.executeQuery();
	    	System.out.println("sql");
			//process result set
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String employee_id=rs.getString("employee_id");
				String employee_status=rs.getString("employee_status");
				String emp_contribute_amt=rs.getString("emp_contribute_amt");
				//create a new student object
				Event_Details tempEvent_Details = new Event_Details(eventId,employee_id,emp_contribute_amt,employee_status);
				listEventDetails.add(tempEvent_Details);
				System.out.println("get event");
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return listEventDetails;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}
	
	
	
	
	public Event EditEvent(String event_id) throws Exception{
		Event objEvent=null;
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try{
			String status="approved";
		
			//get a connection
			con=ConnectionClass.getConnection();
			//create sql statement
			String sql="select * from AMAL_EVENT where event_id=?";
			/*where EVENT_STATUS='approved'*/
			stmt= con.createStatement();
			//execute query
			ps=con.prepareStatement(sql);
			 ps.setString(1,event_id);
	    	rs=ps.executeQuery();
		
			//process result set
			if(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id1=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				 objEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id1,coordinator_id,emp_expect_amt);
				
				
			}
			else{
				throw new Exception("Could not find the event-id"+event_id);
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return objEvent;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}
	

	public void Update(Event objEventBean) throws Exception{
		Connection con=null;
		Statement stmt= null;
		int rs = 0;
		PreparedStatement ps=null;
		try{
			
			//get a connection
			con=ConnectionClass.getConnection();
			//create sql statement
			String sql="update amal_event set event_name=?,start_date=?,end_date=?,venue=?,event_time=?,expected_amount=?,coordinator_id=?,emp_expect_amt=? where event_id=?";
			/*where EVENT_STATUS='approved'*/
			stmt= con.createStatement();
			//execute query
			ps=con.prepareStatement(sql);
			 ps.setString(1,objEventBean.getEvent_name());
			 ps.setString(2,objEventBean.getStart_date());
			 ps.setString(3,objEventBean.getEnd_date());
			 ps.setString(4,objEventBean.getVenue());
			 ps.setString(5,objEventBean.getEvent_time());
			 ps.setFloat(6,objEventBean.getExpected_amount());
			 ps.setString(7,objEventBean.getCoordinator_id());
			 ps.setFloat(8,objEventBean.getEmp_expect_amt());
			 ps.setString(9,objEventBean.getEvent_id());
	    	rs=ps.executeUpdate();
		
			//process result set
			if(rs==1){
				
			}
			else{
				throw new Exception("Could not find the event-id");
			}
			
			}
		finally{
			//close jdbc objects
			close(con,stmt,null);
		}
	
	}

	public String DeleteEvent(String event_id) throws Exception{
		Connection con=null;
		Statement stmt= null;
		int rs = 0;
		PreparedStatement ps=null;
		String status="deleted";
		String s=null;
		try{
			con=ConnectionClass.getConnection();
			String sql="update amal_event set event_status=? where event_id=?";
			stmt= con.createStatement();
		
			ps=con.prepareStatement(sql);
			 ps.setString(1,status);
			 ps.setString(2,event_id);
	    	rs=ps.executeUpdate();
		
			//process result set
			if(rs==1)
				s="success";
				else
					s="fail";
	
	
			
			return s;
		}
		finally{
			//close jdbc objects
			stmt.close();
			con.close();
		}
		
	}
	
	
	public List<Event> EventRequest(Employee objEmp) throws Exception{
		List<Event> list_AddEventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		PreparedStatement ps=null;
		ResultSet rs = null;
		
		try{
			//get a connection
			con=ConnectionClass.getConnection();
			String adminId=objEmp.getEid();
			String status="pending";
			//create sql statement
			String sql="select * from AMAL_EVENT where event_status=? and admin_id=?";
			/*where EVENT_STATUS='approved'*/
			stmt= con.createStatement();
			ps=con.prepareStatement(sql);
			ps.setString(1,status);
			ps.setString(2,adminId);
	    	rs=ps.executeQuery();
		
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id,coordinator_id,emp_expect_amt);
				list_AddEventBean.add(tempEvent);
				
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_AddEventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}
	
	
	public List<Event> EventReject(Employee objEmp) throws Exception{
		List<Event> list_AddEventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try{
		
			con=ConnectionClass.getConnection();
			String adminId=objEmp.getEid();
			String status="rejected";
			String sql="select * from AMAL_EVENT where event_status=? and admin_id=?";
			/*where EVENT_STATUS='approved'*/
			stmt= con.createStatement();
			ps=con.prepareStatement(sql);
			ps.setString(1,status);
			ps.setString(2,adminId);
	    	rs=ps.executeQuery();
		
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id,coordinator_id,emp_expect_amt);
				list_AddEventBean.add(tempEvent);
				
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_AddEventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}
	

	public List<Event> EventDeleted(Employee objEmp) throws Exception{
		List<Event> list_AddEventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try{
			//get a connection
			con=ConnectionClass.getConnection();
			String adminId=objEmp.getEid();
			//create sql statement
			String sql="select * from AMAL_EVENT where event_status=? and admin_id=?";
			stmt= con.createStatement();
			ps=con.prepareStatement(sql);
			String status="deleted";
			ps.setString(1,status);
			ps.setString(2,adminId);
	    	rs=ps.executeQuery();
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id,coordinator_id,emp_expect_amt);
				list_AddEventBean.add(tempEvent);
				
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_AddEventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}
	
	
	public List<Event> EventClosed(Employee objEmp) throws Exception{
		List<Event> list_AddEventBean = new ArrayList<>();
		Connection con=null;
		Statement stmt= null;
		ResultSet rs = null;
		PreparedStatement ps=null;
		try{
			//get a connection
			con=ConnectionClass.getConnection();
			String adminId=objEmp.getEid();
			//create sql statement
			String sql="select * from AMAL_EVENT where  event_status=? and admin_id=?";
			/*where EVENT_STATUS='approved'*/
			ps=con.prepareStatement(sql);
			String status="closed";
			ps.setString(1,status);
			ps.setString(2,adminId);
	    	rs=ps.executeQuery();
			while(rs.next()){
				// retrieve data from result set row
				String eventId=rs.getString("EVENT_ID");
				String eventName=rs.getString("EVENT_NAME");
				String sdate=rs.getString("START_DATE");
				String edate=rs.getString("END_DATE");
				String e_venue=rs.getString("VENUE");
				String e_time=rs.getString("EVENT_TIME");
				Float e_exp_amount=rs.getFloat("EXPECTED_AMOUNT");
				Float e_actual_amt=rs.getFloat("TOTAL_AMOUNT");
				String e_expect_amt=rs.getString("EVENT_STATUS");
				String admin_id=rs.getString("ADMIN_ID");
				String coordinator_id=rs.getString("COORDINATOR_ID");
				Float emp_expect_amt=rs.getFloat("EMP_EXPECT_AMT");
				//create a new student object
				Event tempEvent = new Event(eventId,eventName,sdate,edate,e_venue,e_time,e_exp_amount,e_actual_amt,e_expect_amt,admin_id,coordinator_id,emp_expect_amt);
				list_AddEventBean.add(tempEvent);
				
			}
		/*	for(AddEventBean temp:list_AddEventBean){
				System.out.println("Name"+temp.getEvent_name());
			}*/
			
			return list_AddEventBean;
		}
		finally{
			//close jdbc objects
			close(con,stmt,rs);
		}
		
	}
	

	private void close(Connection con, Statement stmt, ResultSet rs) {
		try{
			if(rs!=null){
				rs.close();
			}
			if(stmt!=null){
				stmt.close();
			}
			if(con!=null){
				con.close();
			}
			
		}
		catch(Exception exc){
			exc.printStackTrace();
		}
	}



}
