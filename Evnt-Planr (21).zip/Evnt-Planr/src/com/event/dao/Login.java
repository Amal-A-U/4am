package com.event.dao;

import java.io.FileNotFoundException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Date;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.event.bean.Employee;
import com.event.bean.Login_FormBean;
import com.event.serviceimpl.SendMail;
import com.event.web.jdbc.ConnectionClass;

public class Login {
	Connection con=null;
	Statement stmt= null;
	ResultSet rs1 = null;
	ResultSet rs2 = null;
	ResultSet rs0 = null;
	ResultSet rs = null;
	String sql = null;
	// login.jsp-->submit-->LoginForm(servlet) 
	public String CheckCredentials(Login_FormBean objLogin_FormBean) throws SQLException, FileNotFoundException {
		String username=objLogin_FormBean.getUsername();
		String password=objLogin_FormBean.getPassword();
		String status="admin";
		String status1="employee";
		String status0="Main";
		    con=ConnectionClass.getConnection();
			stmt=con.createStatement();
			PreparedStatement ps=null;
			PreparedStatement ps1=null;
	     String sql1="select employee_id,password from amal_employee where employee_id=? and password=? and status=?";
	     ps=con.prepareStatement(sql1);
	     ps.setString(1,username);
	     ps.setString(2,password);
	     ps.setString(3,status);
	      rs1 = ps.executeQuery();
	    
	
		 sql1="select employee_id,password from amal_employee where employee_id=? and password=? and status=?";

		
		 ps1=con.prepareStatement(sql1);
	     ps1.setString(1,username);
	     ps1.setString(2,password);
	     ps1.setString(3,status1);
	     rs2 = ps1.executeQuery();
	     String sql0="select employee_id,password from amal_employee where employee_id=? and password=? and status=?";
	     ps=con.prepareStatement(sql0);
	     ps.setString(1,username);
	     ps.setString(2,password);
	     ps.setString(3,status0);
	      rs0 = ps.executeQuery();
			if(rs1.next()){
				String uname=rs1.getString(1);
				String paswd=rs1.getString(2);
				System.out.println(uname);
				System.out.println(paswd);
				if(uname.equals(username) && paswd.equals(password)){
					
				return "admin";
				}
			}
			else if(rs2.next()){
				String uname=rs2.getString(1);
				String paswd=rs2.getString(2);
				if(uname.equals(username) && paswd.equals(password)){
					
				return "employee";
				}
			}
			else if(rs0.next()){
				String uname=rs0.getString(1);
				String paswd=rs0.getString(2);
				if(uname.equals(username) && paswd.equals(password)){
					
				return "Main";
				}
			}
			
			return "not registered";
	}
	// login.jsp-->forgot Password-->LoginForm(servlet) 
	public int forgotPass(Employee objEmployee) throws FileNotFoundException, SQLException, AddressException, MessagingException {
		String email=objEmployee.getEmail();
	    con=ConnectionClass.getConnection();
	    List<String> list=new ArrayList<String>();
	    int result=0;
	    
	    
		 stmt=con.createStatement();
		 ResultSet rs0=null;
	     PreparedStatement ps0=null;
	     String sql0="select employee_id,password from amal_employee where email=?";
	     ps0=con.prepareStatement(sql0);
	     ps0.setString(1,email);
	     rs0 = ps0.executeQuery();
	 	if(rs0.next()){
	 		result=1;
			String uname=rs0.getString(1);
			String paswd=rs0.getString(2);
			list.add(email);
			  String body="Hi\n \tUSER NAME :"+uname+"\n \tPASSWORD :"+paswd+"\n\t\n\n\nPLEASE REMEMBER THIS!!\n\nThanks and regards\nAmal AU ";
			  SendMail objMail= new SendMail();
			  objMail.sendEmail("PASSWORD",list,"extern_au.amal@allianz.com",body);
			   
			   
		}
	
		return result;
	}
// login.jsp-->submit-->LoginForm(servlet) 
	public void CheckDate() throws SQLException, ParseException {
        Date sysdate=new Date();
        System.out.println(sysdate);
        String status="approved";
        String status1="closed";
        String end_date=null;
        String event_id=null;
   	 ResultSet rs3=null;
     System.out.println("1");
     PreparedStatement ps3=null;
     System.out.println("2");
     String sql3="select event_id,end_date from amal_event where event_status=?";
     ps3=con.prepareStatement(sql3);
     ps3.setString(1,status);
     System.out.println("1");
     rs3 = ps3.executeQuery();
        while(rs3.next()){
        	   System.out.println("2");
        	event_id=rs3.getString("event_id");
        	end_date=rs3.getString("end_date");
        	  Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(end_date);
        	System.out.println(date1);
        	if((date1.compareTo(sysdate))>0){
        		   System.out.println("1");
        		 int rs2=0;
        	     PreparedStatement ps2=null;
        	     String sql2="update amal_event set event_status=? where event_id=?";
        	     ps2=con.prepareStatement(sql2);
        	     ps2.setString(1,status1);
        	     ps2.setString(2,event_id);
        	     rs2 = ps2.executeUpdate();
        		
        	}
       
        }
        
        
     /*   String date=objTicketBookingBean.getDate();
                       Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(date);
                       int dateresult = date1.compareTo(sysdate);  

                       PreparedStatement preparedStatement = null;                
                       try
                       {   if(dateresult<0)
                         {
                                       result="not possible";
                         }
*/
		
	}

	
}
