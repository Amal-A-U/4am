package com.event.dao;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.event.bean.Employee;
import com.event.web.jdbc.ConnectionClass;

public class DropDownEmpDao {
	public List<Employee> list(String id2) throws SQLException, FileNotFoundException {
		Connection con=null;
		
		ResultSet rs=null;
		PreparedStatement ps=null;
		con=ConnectionClass.getConnection();

		List<Employee> empList = new ArrayList<>();
		try{
		  String s = "SELECT EMPLOYEE_ID,fname,lname  FROM AMAL_EMPLOYEE where dept_id in (select dept_id from amal_employee  where employee_id=?)";
		  ps=con.prepareStatement(s);
			 ps.setString(1,id2);
		rs=ps.executeQuery();
		  
		  
		 
			while (rs.next()) {
				 
                String id = rs.getString("EMPLOYEE_ID");
                String fname = rs.getString("fname");
                String lname = rs.getString("lname");
                
                Employee emp = new Employee(id,fname,lname);
                   
               empList.add(emp);
           
            }   
		  } catch (SQLException ex) {
	            ex.printStackTrace();
	            throw ex;
	        }       
	         
	        return empList;
	    }
}
