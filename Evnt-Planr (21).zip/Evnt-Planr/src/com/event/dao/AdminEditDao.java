package com.event.dao;

public class AdminEditDao {

}
